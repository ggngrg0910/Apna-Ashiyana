<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Apna Ashiyana</title>
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"
    />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
  </head>
  <body>
    <!--Navbar Starts-->
    <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php"
          ><img src="assets/ghar1.jpg" alt="" /><span class="s1">Apna</span
          ><span class="s2">Ashiyana</span></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
          <form class="d-flex" role="search">
            <input
              class="form-control rounded-0 form1 me-2"
              type="search"
              placeholder="Search for Locality..."
              aria-label="Search"
            />
            <button class="btn btn2 rounded-0 me-5" type="submit">
              <i class="fas fa-search"></i>
            </button>
          </form>
          <a href="contact.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Contact us
            </button></a>
          <a href="login.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Login
            </button></a>
            <a href="signup.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Register
            </button></a>
            
          <!--<button onclick="myFunction()">Toggle dark mode</button>-->
        </div>
      </div>
    </nav>
    <!--Navbar Ends-->

    <div class="img-slider">
      <div class="slide active">
        <img src="assets/340557.jpg" alt="" />
        <div class="info">
          <h2>Buy your Dream House</h2>
          <p>Keep calm and lets find your dream home</p>
        </div>
      </div>
      <div class="slide">
        <img src="assets/340557.jpg" alt="" />
        <div class="info">
          <h2>Properties for rent</h2>
          <p>Home is not a place its a feeling</p>
        </div>
      </div>
      <div class="slide">
        <img src="assets/340557.jpg" alt="" />
        <div class="info">
          <h2>Plots for sale</h2>
          <p>The best investment on earth is earth</p>
        </div>
      </div>
      <div class="navigation">
        <div class="btn active"></div>
        <div class="btn"></div>
        <div class="btn"></div>
      </div>
    </div>

    
    <div class="demand">
      <h2>Available Properties</h2>
    </div>
    <!-- Swiper -->
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img src="assets/house1.jpg" alt="img" />
          <span class="discount-tag">50% off</span>
          <div class="info1">
            <h3>3 BHK Flat</h3>
            <p>Sec 17,Chandigarh</p>
            <h6>Price: <span class="duration">65-75</span> Lac.</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house2.jpg" alt="img" />
          <span class="discount-tag">30% off</span>
          <div class="info1">
            <h3>1 BHK Flat</h3>
            <p>Sec 5,Gurugam</p>
            <h6>Price: <span class="duration">22-30</span> Lac.</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house3.jpg" alt="img" />
          <span class="discount-tag">40% off</span>
          <div class="info1">
            <h3>Villa</h3>
            <p>Punjabi Bagh, Delhi</p>
            <h6>Price: <span class="duration">1.5-2</span> Cr </h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house4.jpg" alt="img" />
          <span class="discount-tag">15% off</span>
          <div class="info1">
            <h3>2 BHK Flat</h3>
            <p>Sas Nagar, Mohali</p>
            <h6>Price: <span class="duration">35-40</span> Lac.</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house5.jpg" alt="img" />
          <span class="discount-tag">30% off</span>
          <div class="info1">
            <h3>Fully Furnished Flat</h3>
            <p>Green Park, Delhi</p>
            <h6>Price: <span class="duration">50</span> Lac.</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house6.jpg" alt="img" />
          <span class="discount-tag">50% off</span>
          <div class="info1">
            <h3>Semi Furnished</h3>
            <p>Sector 15, Chandigarh</p>
            <h6>Price: <span class="duration">15-20</span> Lac.</h6>
            <a href="#">Know More</a>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
    </div>

  
    <br />
    <div class="demand">
      <h2>House for Rent</h2>
    </div>
    <!-- Swiper -->
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img src="assets/house7.webp" alt="img" />
          <span class="discount-tag">10% off</span>
          <div class="info1">
            <h3>1 BHK Flat</h3>
            <p>Sec 74, Mohali</p>
            <h6>Rent: <span class="duration">10K-15</span>K</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house8.avif" alt="img" />
          <span class="discount-tag">25% off</span>
          <div class="info1">
            <h3>3 BHK Flat</h3>
            <p>Sector 7, Delhi</p>
            <h6>Rent: <span class="duration">40K-50</span>K</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house9.jpg" alt="img" />
          <span class="discount-tag">20% off</span>
          <div class="info1">
            <h3>2 BHK Flat</h3>
            <p>New Jawahar Nagar, Jalandhar</p>
            <h6>Rent: <span class="duration">25K-30</span>K</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house10.jpg" alt="img" />
          <span class="discount-tag">15% off</span>
          <div class="info1">
            <h3>Apartments</h3>
            <p>Delhi NCR</p>
            <h6>Rent: <span class="duration">20K-40</span>K</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house11.jpg" alt="img" />
          <span class="discount-tag">30% off</span>
          <div class="info1">
            <h3>Ready To Move</h3>
            <p>Near Gateway of India, Mumbai</p>
            <h6>Rent: <span class="duration">50K-60</span>K</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/house12.jpg" alt="img" />
          <span class="discount-tag">50% off</span>
          <div class="info1">
            <h3>Semi Furnished</h3>
            <p>Church Street, Bengaluru </p>
            <h6>Rent: <span class="duration">35K-40</span>K</h6>
            <a href="#">Know More</a>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
    </div>

    <!--Footer starts-->
    <footer>
      <div class="content">
        <div class="top">
          <div class="logo-details">
            <a class="navbar-brand" href="index.html"
              ><img src="assets/footer_ghar.png" alt="" /><span
                class="footer-s1"
                >Apna</span
              ><span class="footer-s2">Ashiyana</span></a
            >
          </div>
          <div class="media-icons">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
          </div>
        </div>
        <div class="link-boxes">
          <ul class="box">
            <li class="link_name">Company</li>
            <li><a href="index.html">Careers</a></li>
            <li><a href="aboutus.html">About us</a></li>
            <li><a href="contact.php">Contact us</a></li>
            <li><a href="index.html">Privacy Policy</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Explore</li>
            <li><a href="#">News</a></li>
            <li><a href="#">Home Loans</a></li>
            <li><a href="#">Sitemap</a></li>
            <li><a href="#">International</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Account</li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">My account</a></li>
            <li><a href="#">Prefrences</a></li>
            <li><a href="#">Purchase</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Service Providers</li>
            <li><a href="#">Architects & Engineers</a></li>
            <li><a href="#">Contractors & Masons</a></li>
            <li><a href="#">Fabricators</a></li>
            <li><a href="#">Dealers</a></li>
          </ul>
          <ul class="box input-box">
            <li class="link_name">Subscribe</li>
            <li><input type="text" placeholder="Enter your email" /></li>
            <li><input type="button" value="Subscribe" /></li>
          </ul>
        </div>
      </div>
      <hr />
      <div class="bottom-details">
        <div class="bottom_text">
          <span class="copyright_text"
            >Copyright © 2022&nbsp;&nbsp; <a href="index.html">Apna Ashiyana</a>All
            rights reserved</span
          >
          <span class="policy_terms">
            <a href="privacy.html">Privacy policy</a>
            <a href="terms_condition.html">Terms & condition</a>
          </span>
        </div>
      </div>
    </footer>

    <script type="text/javascript">
      var slides = document.querySelectorAll(".slide");
      var btns = document.querySelectorAll(".btn");
      let currentSlide = 1;

      // Javascript for image slider manual navigation
      var manualNav = function (manual) {
        slides.forEach((slide) => {
          slide.classList.remove("active");

          btns.forEach((btn) => {
            btn.classList.remove("active");
          });
        });

        slides[manual].classList.add("active");
        btns[manual].classList.add("active");
      };

      btns.forEach((btn, i) => {
        btn.addEventListener("click", () => {
          manualNav(i);
          currentSlide = i;
        });
      });

      // Javascript for image slider autoplay navigation
      var repeat = function (activeClass) {
        let active = document.getElementsByClassName("active");
        let i = 1;

        var repeater = () => {
          setTimeout(function () {
            [...active].forEach((activeSlide) => {
              activeSlide.classList.remove("active");
            });

            slides[i].classList.add("active");
            btns[i].classList.add("active");
            i++;

            if (slides.length == i) {
              i = 0;
            }
            if (i >= slides.length) {
              return;
            }
            repeater();
          }, 10000);
        };
        repeater();
      };
      repeat();
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: "auto",
        spaceBetween: 40,
        centeredSlides: true,
        grabCursor: true,
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    </script>

    <script src="assets/js/script.js"></script>
  </body>
</html>
